/**
 * ひらがな・カタカナをローマ字に変換するユーティリティ
 * 拗音（きゃ、しゃ等）や濁音・半濁音にも対応
 */

const KANA_TO_ROMAJI = {
  // 母音
  'あ': 'a', 'い': 'i', 'う': 'u', 'え': 'e', 'お': 'o',
  
  // か行
  'か': 'ka', 'き': 'ki', 'く': 'ku', 'け': 'ke', 'こ': 'ko',
  
  // さ行
  'さ': 'sa', 'し': 'shi', 'す': 'su', 'せ': 'se', 'そ': 'so',
  
  // た行
  'た': 'ta', 'ち': 'chi', 'つ': 'tsu', 'て': 'te', 'と': 'to',
  
  // な行
  'な': 'na', 'に': 'ni', 'ぬ': 'nu', 'ね': 'ne', 'の': 'no',
  
  // は行
  'は': 'ha', 'ひ': 'hi', 'ふ': 'fu', 'へ': 'he', 'ほ': 'ho',
  
  // ま行
  'ま': 'ma', 'み': 'mi', 'む': 'mu', 'め': 'me', 'も': 'mo',
  
  // や行
  'や': 'ya', 'ゆ': 'yu', 'よ': 'yo',
  
  // ら行
  'ら': 'ra', 'り': 'ri', 'る': 'ru', 'れ': 're', 'ろ': 'ro',
  
  // わ行
  'わ': 'wa', 'を': 'wo', 'ん': 'n',
  
  // が行
  'が': 'ga', 'ぎ': 'gi', 'ぐ': 'gu', 'げ': 'ge', 'ご': 'go',
  
  // ざ行
  'ざ': 'za', 'じ': 'ji', 'ず': 'zu', 'ぜ': 'ze', 'ぞ': 'zo',
  
  // だ行
  'だ': 'da', 'ぢ': 'ji', 'づ': 'zu', 'で': 'de', 'ど': 'do',
  
  // ば行
  'ば': 'ba', 'び': 'bi', 'ぶ': 'bu', 'べ': 'be', 'ぼ': 'bo',
  
  // ぱ行
  'ぱ': 'pa', 'ぴ': 'pi', 'ぷ': 'pu', 'ぺ': 'pe', 'ぽ': 'po',
  
  // 拗音（きゃ行）
  'きゃ': 'kya', 'きゅ': 'kyu', 'きょ': 'kyo',
  
  // 拗音（しゃ行）
  'しゃ': 'sha', 'しゅ': 'shu', 'しょ': 'sho',
  
  // 拗音（ちゃ行）
  'ちゃ': 'cha', 'ちゅ': 'chu', 'ちょ': 'cho',
  
  // 拗音（にゃ行）
  'にゃ': 'nya', 'にゅ': 'nyu', 'にょ': 'nyo',
  
  // 拗音（ひゃ行）
  'ひゃ': 'hya', 'ひゅ': 'hyu', 'ひょ': 'hyo',
  
  // 拗音（みゃ行）
  'みゃ': 'mya', 'みゅ': 'myu', 'みょ': 'myo',
  
  // 拗音（りゃ行）
  'りゃ': 'rya', 'りゅ': 'ryu', 'りょ': 'ryo',
  
  // 拗音（ぎゃ行）
  'ぎゃ': 'gya', 'ぎゅ': 'gyu', 'ぎょ': 'gyo',
  
  // 拗音（じゃ行）
  'じゃ': 'ja', 'じゅ': 'ju', 'じょ': 'jo',
  
  // 拗音（びゃ行）
  'びゃ': 'bya', 'びゅ': 'byu', 'びょ': 'byo',
  
  // 拗音（ぴゃ行）
  'ぴゃ': 'pya', 'ぴゅ': 'pyu', 'ぴょ': 'pyo',
  
  // 句読点・記号（無音扱い）
  '。': 'silence', '、': 'silence', '！': 'silence', '？': 'silence',
  ' ': 'silence', '　': 'silence',
};

/**
 * ひらがなテキストをローマ字音素リストに変換
 * @param {string} text - 変換対象のテキスト
 * @returns {string[]} ローマ字音素のリスト
 */
export function kanaToRomaji(text) {
  const romaji = [];
  let i = 0;
  
  while (i < text.length) {
    // 2文字の組み合わせを優先チェック（きゃ、しゃ等）
    if (i + 1 < text.length) {
      const twoChar = text.slice(i, i + 2);
      if (KANA_TO_ROMAJI[twoChar]) {
        romaji.push(KANA_TO_ROMAJI[twoChar]);
        i += 2;
        continue;
      }
    }
    
    // 1文字チェック
    const oneChar = text[i];
    if (KANA_TO_ROMAJI[oneChar]) {
      romaji.push(KANA_TO_ROMAJI[oneChar]);
    } else {
      // 未知の文字は無音扱い
      romaji.push('silence');
    }
    i++;
  }
  
  return romaji;
}

/**
 * ローマ字リストから重複を除去し、単一音素リストを作成
 * @param {string[]} romajiList - ローマ字音素リスト
 * @returns {string[]} 重複を除去した音素リスト
 */
export function getUniquePhonemesFromRomaji(romajiList) {
  return [...new Set(romajiList)];
}

/**
 * テキストから全ての音素を抽出（重複なし）
 * @param {string} text - 変換対象のテキスト
 * @returns {string[]} 重複を除去した音素リスト
 */
export function extractPhonemes(text) {
  const romajiList = kanaToRomaji(text);
  return getUniquePhonemesFromRomaji(romajiList);
}
