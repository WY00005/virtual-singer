/**
 * テキスト感情分析ユーティリティ
 * テキストから感情、強調、疑問などを検出し、
 * 適切なジェスチャー動画の選択に利用
 */

/**
 * テキストから感情スコアを計算
 * @param {string} text - 分析対象のテキスト
 * @returns {object} { positive: number, negative: number, neutral: number }
 */
export function analyzeEmotions(text) {
  // ポジティブ表現
  const positiveKeywords = [
    'いい', '良い', '素晴らしい', '最高', 'すごい', '楽しい',
    'うれしい', '嬉しい', '幸せ', '好き', '大好き', '素敵',
    'かわいい', '美しい', '綺麗', 'ありがとう', '感謝',
  ];
  
  // ネガティブ表現
  const negativeKeywords = [
    '悪い', '最悪', 'つまらない', '退屈', '嫌い', '大嫌い',
    '悲しい', '悲しむ', '辛い', '苦しい', '困る', '困った',
    '怖い', '恐怖', 'ショック', '失望', '残念',
  ];
  
  let positiveCount = 0;
  let negativeCount = 0;
  
  positiveKeywords.forEach(keyword => {
    const regex = new RegExp(keyword, 'g');
    const matches = text.match(regex);
    if (matches) positiveCount += matches.length;
  });
  
  negativeKeywords.forEach(keyword => {
    const regex = new RegExp(keyword, 'g');
    const matches = text.match(regex);
    if (matches) negativeCount += matches.length;
  });
  
  const total = positiveCount + negativeCount || 1;
  
  return {
    positive: positiveCount / total,
    negative: negativeCount / total,
    neutral: total === 0 ? 1 : 0,
  };
}

/**
 * テキストから強調表現を検出
 * @param {string} text - 分析対象のテキスト
 * @returns {boolean} 強調表現が含まれている場合は true
 */
export function hasEmphasis(text) {
  // 感嘆符、複数の感嘆符、大文字（カタカナの場合）
  const emphasisPatterns = [
    /！{2,}/, // 複数の感嘆符
    /！/, // 感嘆符
    /[ァ-ヴー]{3,}/, // 3文字以上のカタカナ（伸ばし音を含む）
  ];
  
  return emphasisPatterns.some(pattern => pattern.test(text));
}

/**
 * テキストから疑問表現を検出
 * @param {string} text - 分析対象のテキスト
 * @returns {boolean} 疑問表現が含まれている場合は true
 */
export function hasQuestion(text) {
  return /？/.test(text);
}

/**
 * テキストから挨拶表現を検出
 * @param {string} text - 分析対象のテキスト
 * @returns {boolean} 挨拶表現が含まれている場合は true
 */
export function hasGreeting(text) {
  const greetingKeywords = [
    'こんにちは', 'おはよう', 'おはようございます',
    'こんばんは', 'おやすみなさい', 'さようなら',
    'さよなら', 'じゃあね', 'またね', 'またあした',
    'よろしく', 'はじめまして', 'お疲れ様',
  ];
  
  return greetingKeywords.some(keyword => text.includes(keyword));
}

/**
 * テキストから複数の感情・表現を検出して総合的に分析
 * @param {string} text - 分析対象のテキスト
 * @returns {object} 分析結果
 */
export function analyzeText(text) {
  const emotions = analyzeEmotions(text);
  const emphasis = hasEmphasis(text);
  const question = hasQuestion(text);
  const greeting = hasGreeting(text);
  
  // 主要な感情を判定
  let dominantEmotion = 'neutral';
  if (emotions.positive > emotions.negative && emotions.positive > 0.3) {
    dominantEmotion = 'happy';
  } else if (emotions.negative > emotions.positive && emotions.negative > 0.3) {
    dominantEmotion = 'sad';
  }
  
  return {
    emotions,
    emphasis,
    question,
    greeting,
    dominantEmotion,
  };
}

/**
 * 分析結果からジェスチャーカテゴリを推奨
 * @param {object} analysis - analyzeText() の戻り値
 * @returns {string} 推奨されるジェスチャーカテゴリ
 */
export function recommendGestureCategory(analysis) {
  // 優先順位: greeting > question > emphasis > dominantEmotion > idle
  
  if (analysis.greeting) {
    return 'greeting';
  }
  
  if (analysis.question) {
    return 'question';
  }
  
  if (analysis.emphasis) {
    return 'emphasis';
  }
  
  switch (analysis.dominantEmotion) {
    case 'happy':
      return 'happy';
    case 'sad':
      return 'sad';
    default:
      return 'idle';
  }
}
