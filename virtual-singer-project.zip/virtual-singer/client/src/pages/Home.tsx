import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Upload, Settings, Info } from 'lucide-react';
import TextInput from '@/components/TextInput';
import ProgressBar from '@/components/ProgressBar';
import VideoPreview from '@/components/VideoPreview';
import GestureSelector from '@/components/GestureSelector';
import { useAuth } from '@/_core/hooks/useAuth';
import { APP_LOGO, APP_TITLE } from '@/const';

/**
 * ホームページ
 * バーチャルシンガーの主要な機能を提供するメインページ
 */
export default function Home() {
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 状態管理
  const [videoManifest, setVideoManifest] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressStatus, setProgressStatus] = useState('');
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
  const [selectedGestures, setSelectedGestures] = useState<string[]>([]);
  const [error, setError] = useState<string>('');

  // 動画マニフェストのアップロード処理
  const handleManifestUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const manifest = JSON.parse(event.target?.result as string);
        setVideoManifest(manifest);
        setError('');
      } catch (err) {
        setError('動画マニフェストの形式が正しくありません');
      }
    };
    reader.readAsText(file);
  };

  // 動画生成処理
  const handleGenerateVideo = async (text: string) => {
    if (!videoManifest) {
      setError('動画マニフェストをアップロードしてください');
      return;
    }

    setIsProcessing(true);
    setProgress(0);
    setProgressStatus('初期化中...');
    setError('');

    try {
      // シミュレーション: 実際の処理に置き換える
      // ステップ1: 音声合成
      setProgress(10);
      setProgressStatus('音声を合成しています...');
      await new Promise(resolve => setTimeout(resolve, 1000));

      // ステップ2: タイムライン生成
      setProgress(20);
      setProgressStatus('タイムラインを生成しています...');
      await new Promise(resolve => setTimeout(resolve, 1000));

      // ステップ3: ジェスチャー選択
      setProgress(30);
      setProgressStatus('ジェスチャーを選択しています...');
      await new Promise(resolve => setTimeout(resolve, 1000));

      // ステップ4: 動画合成
      setProgress(70);
      setProgressStatus('動画を合成しています...');
      await new Promise(resolve => setTimeout(resolve, 2000));

      // ステップ5: 完成
      setProgress(100);
      setProgressStatus('完成しました！');

      // ダミーの動画URL（実際には生成された動画のURLを使用）
      setGeneratedVideoUrl('blob:https://example.com/dummy-video');

      await new Promise(resolve => setTimeout(resolve, 500));
    } catch (err) {
      setError('動画生成中にエラーが発生しました');
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  // 利用可能なジェスチャーの取得
  const availableGestures = videoManifest?.gestures || [] as any[];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      {/* ヘッダー */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {APP_LOGO && (
              <img src={APP_LOGO} alt={APP_TITLE} className="w-8 h-8" />
            )}
            <h1 className="text-2xl font-bold">{APP_TITLE}</h1>
          </div>
          {user && (
            <div className="text-sm text-muted-foreground">
              ログイン: {user.name || user.email}
            </div>
          )}
        </div>
      </header>

      {/* メインコンテンツ */}
      <main className="container mx-auto px-4 py-8">
        {/* エラー表示 */}
        {error && (
          <Card className="mb-6 border-destructive bg-destructive/10">
            <CardContent className="pt-6">
              <p className="text-sm text-destructive">{error}</p>
            </CardContent>
          </Card>
        )}

        {/* マニフェストアップロード */}
        {!videoManifest && (
          <Card className="mb-6 border-primary/50 bg-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5" />
                動画マニフェストをアップロード
              </CardTitle>
              <CardDescription>
                口形とジェスチャーの動画情報を定義したJSONファイルをアップロードしてください
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <Input
                  ref={fileInputRef}
                  type="file"
                  accept=".json"
                  onChange={handleManifestUpload}
                  className="hidden"
                />
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  className="gap-2"
                >
                  <Upload className="w-4 h-4" />
                  ファイルを選択
                </Button>
                <p className="text-sm text-muted-foreground flex items-center">
                  video-manifest.json をアップロード
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* マニフェスト読み込み完了 */}
        {videoManifest && (
          <Card className="mb-6 border-green-500/50 bg-green-50 dark:bg-green-950/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-green-900 dark:text-green-100">
                    ✅ 動画マニフェストが読み込まれました
                  </p>
                  <p className="text-sm text-muted-foreground">
                    口形: {(videoManifest as any)?.mouths?.length || 0}個 | ジェスチャー: {(videoManifest as any)?.gestures?.length || 0}個
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setVideoManifest(null);
                    setGeneratedVideoUrl(null);
                  }}
                >
                  変更
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* メインタブ */}
        {videoManifest && (
          <Tabs defaultValue="generate" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="generate">生成</TabsTrigger>
              <TabsTrigger value="gestures">ジェスチャー</TabsTrigger>
              <TabsTrigger value="settings">設定</TabsTrigger>
            </TabsList>

            {/* 生成タブ */}
            <TabsContent value="generate" className="space-y-6 mt-6">
              <TextInput
                onGenerate={handleGenerateVideo}
                isProcessing={isProcessing}
              />
              <ProgressBar
                progress={progress}
                status={progressStatus}
                isVisible={isProcessing}
              />
              <VideoPreview
                videoUrl={generatedVideoUrl}
                isLoading={isProcessing}
              />
            </TabsContent>

            {/* ジェスチャータブ */}
            <TabsContent value="gestures" className="mt-6">
              <GestureSelector
                selectedGestures={selectedGestures}
                availableGestures={availableGestures}
                onGestureSelect={setSelectedGestures}
                isEditable={!isProcessing}
              />
            </TabsContent>

            {/* 設定タブ */}
            <TabsContent value="settings" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="w-5 h-5" />
                    設定
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">音声合成エンジン</label>
                    <p className="text-sm text-muted-foreground mt-1">
                      Web Speech API (デフォルト)
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium">動画フォーマット</label>
                    <p className="text-sm text-muted-foreground mt-1">
                      MP4 (H.264)
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium">解像度</label>
                    <p className="text-sm text-muted-foreground mt-1">
                      1080p (1920x1080)
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}

        {/* 情報カード */}
        {!videoManifest && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="w-5 h-5" />
                使い方
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">1. 動画マニフェストをアップロード</h3>
                <p className="text-sm text-muted-foreground">
                  口形とジェスチャーの動画情報を定義したJSONファイルをアップロードしてください。
                </p>
              </div>
              <div>
                <h3 className="font-medium mb-2">2. テキストを入力</h3>
                <p className="text-sm text-muted-foreground">
                  日本語のテキストを入力して、「動画を生成」ボタンをクリックします。
                </p>
              </div>
              <div>
                <h3 className="font-medium mb-2">3. 動画をダウンロード</h3>
                <p className="text-sm text-muted-foreground">
                  生成された動画をプレビューして、ダウンロードボタンでMP4ファイルを保存します。
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
