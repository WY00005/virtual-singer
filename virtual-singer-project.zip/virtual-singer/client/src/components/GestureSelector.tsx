import React, { useState, useEffect, FC } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check } from 'lucide-react';

/**
 * ジェスチャー選択コンポーネント
 * ユーザーが手動でジェスチャーを選択・カスタマイズできる
 */
interface GestureItem {
  id: string;
  name: string;
  category?: string;
  thumbnail?: string;
  emoji?: string;
}

interface GestureSelectorProps {
  selectedGestures?: string[];
  availableGestures?: GestureItem[];
  onGestureSelect?: (gestures: string[]) => void;
  isEditable?: boolean;
}

const GestureSelector: FC<GestureSelectorProps> = ({
  selectedGestures = [],
  availableGestures = [],
  onGestureSelect = () => {},
  isEditable = true,
}) => {
  const [gestures, setGestures] = useState(selectedGestures);

  useEffect(() => {
    setGestures(selectedGestures);
  }, [selectedGestures]);

  const handleGestureToggle = (gestureId: string) => {
    if (!isEditable) return;

    const isSelected = gestures.includes(gestureId);
    const updated = isSelected
      ? gestures.filter(id => id !== gestureId)
      : [...gestures, gestureId];

    setGestures(updated);
    onGestureSelect(updated);
  };

  // ジェスチャーをカテゴリ別にグループ化
  const groupedGestures = availableGestures.reduce((acc: Record<string, GestureItem[]>, gesture: GestureItem) => {
    const category = gesture.category || 'その他';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(gesture);
    return acc;
  }, {});

  const categories = Object.keys(groupedGestures).sort();

  if (!availableGestures || availableGestures.length === 0) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>ジェスチャー選択</CardTitle>
          <CardDescription>
            利用可能なジェスチャーがありません
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-8">
            <p>動画マニフェストを読み込んでください</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>ジェスチャー選択</CardTitle>
        <CardDescription>
          {isEditable
            ? '動画に含めるジェスチャーを選択してください'
            : 'システムが自動選択したジェスチャーです'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {categories.map(category => (
          <div key={category} className="space-y-3">
            <h3 className="font-semibold text-sm">{category}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {groupedGestures[category].map((gesture: GestureItem) => (
                <button
                  key={gesture.id}
                  onClick={() => handleGestureToggle(gesture.id)}
                  disabled={!isEditable}
                  className={`relative p-3 rounded-lg border-2 transition-all ${
                    gestures.includes(gesture.id)
                      ? 'border-primary bg-primary/10'
                      : 'border-muted hover:border-muted-foreground'
                  } ${!isEditable ? 'cursor-not-allowed opacity-75' : 'cursor-pointer'}`}
                >
                  {/* ジェスチャーサムネイル */}
                  {gesture.thumbnail ? (
                    <img
                      src={gesture.thumbnail}
                      alt={gesture.name}
                      className="w-full h-20 object-cover rounded mb-2"
                    />
                  ) : (
                    <div className="w-full h-20 bg-muted rounded mb-2 flex items-center justify-center text-xs text-muted-foreground">
                      {gesture.emoji || '🎬'}
                    </div>
                  )}

                  {/* ジェスチャー名 */}
                  <p className="text-xs font-medium text-center truncate">
                    {gesture.name}
                  </p>

                  {/* 選択インジケーター */}
                  {gestures.includes(gesture.id) && (
                    <div className="absolute top-1 right-1 bg-primary rounded-full p-1">
                      <Check className="w-3 h-3 text-primary-foreground" />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* 選択状況 */}
        {gestures.length > 0 && (
          <div className="bg-muted p-3 rounded-md">
            <p className="text-sm font-medium mb-2">
              選択済み: {gestures.length}/{availableGestures.length}
            </p>
            <div className="flex flex-wrap gap-2">
              {gestures.map(gestureId => {
                const gesture = availableGestures.find(g => g.id === gestureId);
                return gesture ? (
                  <Badge key={gestureId} variant="secondary">
                    {gesture.name}
                  </Badge>
                ) : null;
              })}
            </div>
          </div>
        )}

        {/* ヒント */}
        <div className="bg-blue-50 dark:bg-blue-950 p-3 rounded-md text-sm text-blue-900 dark:text-blue-100">
          <p className="font-medium mb-1">💡 ヒント:</p>
          <p>
            {isEditable
              ? 'ジェスチャーを選択すると、生成される動画に含まれます。複数選択可能です。'
              : 'システムがテキストの感情や強調に基づいて、最適なジェスチャーを自動選択しました。'}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default GestureSelector;
