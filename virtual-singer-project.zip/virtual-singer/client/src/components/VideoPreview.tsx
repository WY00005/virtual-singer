import React, { useRef, useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, Play, Pause, Volume2, VolumeX } from 'lucide-react';

/**
 * 動画プレビューコンポーネント
 * 生成された動画をプレビューし、ダウンロード可能にする
 */
interface VideoPreviewProps {
  videoUrl?: string | null;
  isLoading?: boolean;
}

export default function VideoPreview({ videoUrl = null, isLoading = false }: VideoPreviewProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleLoadedMetadata = () => {
      setDuration(video.duration);
    };

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime);
    };

    const handleEnded = () => {
      setIsPlaying(false);
    };

    video.addEventListener('loadedmetadata', handleLoadedMetadata);
    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('ended', handleEnded);

    return () => {
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('ended', handleEnded);
    };
  }, []);

  const handlePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleDownload = () => {
    if (videoUrl) {
      const link = document.createElement('a');
      link.href = videoUrl;
      link.download = `virtual-singer-${Date.now()}.mp4`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const formatTime = (seconds: number): string => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  if (!videoUrl) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>動画プレビュー</CardTitle>
          <CardDescription>
            {isLoading
              ? '動画を生成中です...'
              : 'テキストを入力して生成ボタンをクリックすると、ここに動画が表示されます'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="w-full aspect-video bg-muted rounded-lg flex items-center justify-center">
            <div className="text-center">
              <div className="text-muted-foreground mb-2">
                {isLoading ? '⏳ 処理中...' : '📹 プレビュー'}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>動画プレビュー</CardTitle>
        <CardDescription>生成された動画をプレビューしてダウンロードできます</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* 動画プレイヤー */}
        <div className="w-full bg-black rounded-lg overflow-hidden">
          <video
            ref={videoRef}
            src={videoUrl}
            className="w-full h-auto"
            controls={false}
          />
        </div>

        {/* コントロールバー */}
        <div className="space-y-2">
          {/* プログレスバー */}
          <div
            className="h-1 bg-muted rounded-full cursor-pointer hover:h-2 transition-all"
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const percent = (e.clientX - rect.left) / rect.width;
              if (videoRef.current && duration > 0) {
                videoRef.current.currentTime = percent * duration;
              }
            }}
          >
            <div
              className="h-full bg-primary rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* 時間表示 */}
          <div className="text-xs text-muted-foreground">
            {formatTime(currentTime)} / {formatTime(duration)}
          </div>

          {/* コントロールボタン */}
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="ghost"
              onClick={handlePlayPause}
              className="gap-1"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-4 h-4" />
                  一時停止
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  再生
                </>
              )}
            </Button>

            <Button
              size="sm"
              variant="ghost"
              onClick={handleMute}
              className="gap-1"
            >
              {isMuted ? (
                <>
                  <VolumeX className="w-4 h-4" />
                  ミュート中
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4" />
                  音声
                </>
              )}
            </Button>

            <div className="flex-1" />

            <Button
              size="sm"
              onClick={handleDownload}
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              ダウンロード
            </Button>
          </div>
        </div>

        {/* 情報 */}
        <div className="bg-muted p-3 rounded-md text-sm text-muted-foreground">
          <p>✅ 動画が正常に生成されました</p>
          <p className="text-xs mt-1">
            MP4形式でダウンロードできます。SNSやプレゼンテーションで使用できます。
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
