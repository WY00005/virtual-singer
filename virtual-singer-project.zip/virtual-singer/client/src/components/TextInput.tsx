import React, { useState, FC, ChangeEvent, KeyboardEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';

/**
 * テキスト入力フォームコンポーネント
 * ユーザーがテキストを入力し、動画生成を開始するためのUIを提供
 */
interface TextInputProps {
  onGenerate?: (text: string) => void;
  isProcessing?: boolean;
}

const TextInput: FC<TextInputProps> = ({ onGenerate, isProcessing = false }) => {
  const [text, setText] = useState('');
  const [error, setError] = useState('');

  const handleTextChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    setText(value);
    setError('');
  };

  const handleGenerate = () => {
    // バリデーション
    if (!text.trim()) {
      setError('テキストを入力してください');
      return;
    }

    if (text.length > 500) {
      setError('テキストは500文字以内で入力してください');
      return;
    }

    // 親コンポーネントに生成を通知
    if (onGenerate) {
      onGenerate(text);
    }
  };

  const handleClear = () => {
    setText('');
    setError('');
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    // Ctrl+Enter または Cmd+Enter で生成開始
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      handleGenerate();
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>テキスト入力</CardTitle>
        <CardDescription>
          日本語のテキストを入力して、リップシンク動画を生成します
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* テキスト入力エリア */}
        <div className="space-y-2">
          <label htmlFor="text-input" className="text-sm font-medium">
            テキスト
            <span className="text-xs text-muted-foreground ml-2">
              ({text.length}/500)
            </span>
          </label>
          <Textarea
            id="text-input"
            placeholder="例: こんにちは！今日はいい天気ですね。"
            value={text}
            onChange={handleTextChange}
            onKeyDown={handleKeyDown}
            disabled={isProcessing}
            className="min-h-[120px] resize-none"
            maxLength={500}
          />
          {error && (
            <p className="text-sm text-destructive">{error}</p>
          )}
        </div>

        {/* ヒントテキスト */}
        <div className="bg-muted p-3 rounded-md text-sm text-muted-foreground">
          <p className="font-medium mb-1">💡 ヒント:</p>
          <ul className="list-disc list-inside space-y-1">
            <li>自然な日本語で入力してください</li>
            <li>句読点（。、！？）で区切ると、より自然なジェスチャーが生成されます</li>
            <li>Ctrl+Enter で生成を開始できます</li>
          </ul>
        </div>

        {/* ボタングループ */}
        <div className="flex gap-2 justify-end">
          <Button
            variant="outline"
            onClick={handleClear}
            disabled={isProcessing || !text}
          >
            クリア
          </Button>
          <Button
            onClick={handleGenerate}
            disabled={isProcessing || !text.trim()}
            className="gap-2"
          >
            {isProcessing && <Loader2 className="w-4 h-4 animate-spin" />}
            {isProcessing ? '生成中...' : '動画を生成'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default TextInput;
