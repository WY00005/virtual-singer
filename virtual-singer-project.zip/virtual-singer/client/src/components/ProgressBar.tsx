import React from 'react';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

/**
 * プログレスバーコンポーネント
 * 動画生成の進捗状況を表示
 */
export default function ProgressBar({ progress = 0, status = '', isVisible = false }) {
  if (!isVisible) {
    return null;
  }

  // 進捗段階の定義
  const stages = [
    { label: '音声合成', value: 10 },
    { label: 'タイムライン生成', value: 20 },
    { label: 'ジェスチャー選択', value: 30 },
    { label: '動画合成', value: 70 },
    { label: '完成', value: 100 },
  ];

  // 現在の段階を取得
  const currentStage = stages.find(stage => progress <= stage.value) || stages[stages.length - 1];

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg">生成進捗</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* プログレスバー */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">{currentStage.label}</span>
            <span className="text-sm text-muted-foreground">{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* ステップインジケーター */}
        <div className="flex justify-between">
          {stages.map((stage, index) => (
            <div
              key={index}
              className="flex flex-col items-center gap-1"
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium transition-colors ${
                  progress >= stage.value
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground'
                }`}
              >
                {index + 1}
              </div>
              <span className="text-xs text-center text-muted-foreground max-w-[60px]">
                {stage.label}
              </span>
            </div>
          ))}
        </div>

        {/* ステータスメッセージ */}
        {status && (
          <div className="text-sm text-muted-foreground italic">
            {status}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
