/**
 * FFmpeg.wasm を使用した動画合成ロジック
 * ブラウザ内で動画、音声、テキストを合成
 */

import FFmpeg from '@ffmpeg/ffmpeg';

const { FFmpeg: FFmpegClass, fetchFile } = FFmpeg;

class VideoCompositor {
  constructor() {
    this.ffmpeg = null;
    this.isReady = false;
  }

  /**
   * FFmpeg.wasm を初期化
   */
  async initialize() {
    if (this.isReady) return;

    try {
      this.ffmpeg = new FFmpegClass();
      
      // FFmpeg.wasm の初期化
      await this.ffmpeg.load();
      this.isReady = true;
      
      console.log('[VideoCompositor] FFmpeg.wasm initialized');
    } catch (error) {
      console.error('[VideoCompositor] Failed to initialize FFmpeg:', error);
      throw error;
    }
  }

  /**
   * 動画と音声を合成
   * @param {Blob} videoBlob - 動画ファイル
   * @param {Blob} audioBlob - 音声ファイル
   * @param {Object} options - 合成オプション
   * @returns {Promise<Blob>} 合成された動画
   */
  async composeVideoWithAudio(videoBlob, audioBlob, options = {}) {
    if (!this.isReady) {
      await this.initialize();
    }

    const {
      outputFormat = 'mp4',
      videoBitrate = '5000k',
      audioBitrate = '128k',
      onProgress = null,
    } = options;

    try {
      // ファイルをFFmpegのメモリに書き込み
      const videoData = await fetchFile(videoBlob);
      const audioData = await fetchFile(audioBlob);

      this.ffmpeg.FS('writeFile', 'input_video.mp4', videoData);
      this.ffmpeg.FS('writeFile', 'input_audio.mp3', audioData);

      // 進捗コールバック
      if (onProgress) {
        this.ffmpeg.setProgress(({ ratio }) => {
          onProgress(Math.round(ratio * 100));
        });
      }

      // FFmpeg コマンド実行
      // -c:v copy: ビデオコーデックをコピー（高速）
      // -c:a aac: 音声コーデックをAAC
      // -shortest: 短い方の長さに合わせる
      await this.ffmpeg.run(
        '-i', 'input_video.mp4',
        '-i', 'input_audio.mp3',
        '-c:v', 'copy',
        '-c:a', 'aac',
        '-shortest',
        '-b:a', audioBitrate,
        `output.${outputFormat}`
      );

      // 出力ファイルを読み込み
      const outputData = this.ffmpeg.FS('readFile', `output.${outputFormat}`);
      const outputBlob = new Blob([outputData.buffer], { type: `video/${outputFormat}` });

      // メモリをクリア
      this.ffmpeg.FS('unlink', 'input_video.mp4');
      this.ffmpeg.FS('unlink', 'input_audio.mp3');
      this.ffmpeg.FS('unlink', `output.${outputFormat}`);

      return outputBlob;
    } catch (error) {
      console.error('[VideoCompositor] Failed to compose video:', error);
      throw error;
    }
  }

  /**
   * 複数の動画クリップを連結
   * @param {Array<Blob>} videoClips - 動画クリップの配列
   * @param {Object} options - 連結オプション
   * @returns {Promise<Blob>} 連結された動画
   */
  async concatenateVideos(videoClips, options = {}) {
    if (!this.isReady) {
      await this.initialize();
    }

    const {
      outputFormat = 'mp4',
      onProgress = null,
    } = options;

    try {
      // concat demuxer 用のファイルリストを作成
      let concatList = '';
      
      for (let i = 0; i < videoClips.length; i++) {
        const videoData = await fetchFile(videoClips[i]);
        const filename = `clip_${i}.mp4`;
        this.ffmpeg.FS('writeFile', filename, videoData);
        concatList += `file '${filename}'\n`;
      }

      // concat ファイルを書き込み
      this.ffmpeg.FS('writeFile', 'concat_list.txt', concatList);

      // 進捗コールバック
      if (onProgress) {
        this.ffmpeg.setProgress(({ ratio }) => {
          onProgress(Math.round(ratio * 100));
        });
      }

      // FFmpeg コマンド実行
      await this.ffmpeg.run(
        '-f', 'concat',
        '-safe', '0',
        '-i', 'concat_list.txt',
        '-c', 'copy',
        `output.${outputFormat}`
      );

      // 出力ファイルを読み込み
      const outputData = this.ffmpeg.FS('readFile', `output.${outputFormat}`);
      const outputBlob = new Blob([outputData.buffer], { type: `video/${outputFormat}` });

      // メモリをクリア
      for (let i = 0; i < videoClips.length; i++) {
        this.ffmpeg.FS('unlink', `clip_${i}.mp4`);
      }
      this.ffmpeg.FS('unlink', 'concat_list.txt');
      this.ffmpeg.FS('unlink', `output.${outputFormat}`);

      return outputBlob;
    } catch (error) {
      console.error('[VideoCompositor] Failed to concatenate videos:', error);
      throw error;
    }
  }

  /**
   * 動画にテキストオーバーレイを追加
   * @param {Blob} videoBlob - 動画ファイル
   * @param {string} text - 追加するテキスト
   * @param {Object} options - テキストオプション
   * @returns {Promise<Blob>} テキスト付き動画
   */
  async addTextOverlay(videoBlob, text, options = {}) {
    if (!this.isReady) {
      await this.initialize();
    }

    const {
      outputFormat = 'mp4',
      fontSize = 24,
      fontColor = 'white',
      x = '(w-text_w)/2',
      y = '(h-text_h)/2',
      onProgress = null,
    } = options;

    try {
      const videoData = await fetchFile(videoBlob);
      this.ffmpeg.FS('writeFile', 'input_video.mp4', videoData);

      // 進捗コールバック
      if (onProgress) {
        this.ffmpeg.setProgress(({ ratio }) => {
          onProgress(Math.round(ratio * 100));
        });
      }

      // FFmpeg コマンド実行
      // drawtext フィルタを使用してテキストを追加
      const filterComplex = `drawtext=text='${text}':fontsize=${fontSize}:fontcolor=${fontColor}:x=${x}:y=${y}`;

      await this.ffmpeg.run(
        '-i', 'input_video.mp4',
        '-vf', filterComplex,
        '-c:a', 'copy',
        `output.${outputFormat}`
      );

      // 出力ファイルを読み込み
      const outputData = this.ffmpeg.FS('readFile', `output.${outputFormat}`);
      const outputBlob = new Blob([outputData.buffer], { type: `video/${outputFormat}` });

      // メモリをクリア
      this.ffmpeg.FS('unlink', 'input_video.mp4');
      this.ffmpeg.FS('unlink', `output.${outputFormat}`);

      return outputBlob;
    } catch (error) {
      console.error('[VideoCompositor] Failed to add text overlay:', error);
      throw error;
    }
  }

  /**
   * 動画の情報を取得
   * @param {Blob} videoBlob - 動画ファイル
   * @returns {Promise<Object>} 動画情報
   */
  async getVideoInfo(videoBlob) {
    if (!this.isReady) {
      await this.initialize();
    }

    try {
      const videoData = await fetchFile(videoBlob);
      this.ffmpeg.FS('writeFile', 'input_video.mp4', videoData);

      // ffprobe コマンドで動画情報を取得
      await this.ffmpeg.run(
        '-v', 'error',
        '-show_format',
        '-show_streams',
        '-print_format', 'json',
        'input_video.mp4'
      );

      // 出力を読み込み
      const output = this.ffmpeg.FS('readFile', 'output.json', { encoding: 'utf8' });
      const info = JSON.parse(output);

      // メモリをクリア
      this.ffmpeg.FS('unlink', 'input_video.mp4');
      this.ffmpeg.FS('unlink', 'output.json');

      return info;
    } catch (error) {
      console.error('[VideoCompositor] Failed to get video info:', error);
      throw error;
    }
  }

  /**
   * FFmpeg.wasm をクリーンアップ
   */
  async cleanup() {
    if (this.ffmpeg && this.isReady) {
      try {
        // FFmpeg プロセスを終了
        this.ffmpeg.exit();
        this.isReady = false;
        console.log('[VideoCompositor] FFmpeg.wasm cleaned up');
      } catch (error) {
        console.error('[VideoCompositor] Failed to cleanup:', error);
      }
    }
  }
}

// シングルトンインスタンス
let instance = null;

export function getVideoCompositor() {
  if (!instance) {
    instance = new VideoCompositor();
  }
  return instance;
}

export default VideoCompositor;
