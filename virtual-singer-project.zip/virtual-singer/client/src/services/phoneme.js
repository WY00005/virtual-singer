/**
 * 音素タイムライン生成サービス
 * テキストから音素リストを生成し、音声の長さに基づいてタイムラインを作成
 */

import { kanaToRomaji } from '../utils/kanaToRomaji';
import { getPhonememeDuration } from '../../shared/phonemeMapping';

/**
 * 音素タイムラインを生成
 * テキストをローマ字音素に変換し、各音素の開始・終了時間を計算
 * 
 * @param {string} text - 入力テキスト（ひらがな）
 * @param {number} totalDurationMs - 音声の総継続時間（ミリ秒）
 * @returns {array} 音素タイムラインの配列
 * 
 * @example
 * const timeline = createPhonemeTimeline('こんにちは', 2000);
 * // [
 * //   { phoneme: 'ko', start_ms: 0, end_ms: 200, duration_ms: 200 },
 * //   { phoneme: 'n', start_ms: 200, end_ms: 300, duration_ms: 100 },
 * //   ...
 * // ]
 */
export function createPhonemeTimeline(text, totalDurationMs) {
  // テキストをローマ字音素に変換
  const romajiList = kanaToRomaji(text);
  
  // 各音素の基本継続時間を取得
  const timeline = [];
  let currentTime = 0;
  
  for (const phoneme of romajiList) {
    const duration = getPhonememeDuration(phoneme);
    
    timeline.push({
      phoneme: phoneme,
      start_ms: currentTime,
      end_ms: currentTime + duration,
      duration_ms: duration,
    });
    
    currentTime += duration;
  }
  
  // 音声の実際の長さに合わせてタイムラインをスケーリング
  // 例: 計算結果が 3000ms だが、実際の音声が 2000ms の場合、
  // スケールファクターは 2000/3000 = 0.667
  if (currentTime > 0) {
    const scaleFactor = totalDurationMs / currentTime;
    
    timeline.forEach(item => {
      item.start_ms *= scaleFactor;
      item.end_ms *= scaleFactor;
      item.duration_ms *= scaleFactor;
    });
  }
  
  return timeline;
}

/**
 * 音素タイムラインをマージ（連続する同じ音素を結合）
 * 
 * @param {array} timeline - 音素タイムライン
 * @returns {array} マージされたタイムライン
 */
export function mergeConsecutivePhonemes(timeline) {
  if (timeline.length === 0) return [];
  
  const merged = [];
  let current = { ...timeline[0] };
  
  for (let i = 1; i < timeline.length; i++) {
    const next = timeline[i];
    
    // 同じ音素が連続している場合、マージ
    if (current.phoneme === next.phoneme) {
      current.end_ms = next.end_ms;
      current.duration_ms = current.end_ms - current.start_ms;
    } else {
      merged.push(current);
      current = { ...next };
    }
  }
  
  merged.push(current);
  return merged;
}

/**
 * タイムラインから特定の時間範囲の音素を取得
 * 
 * @param {array} timeline - 音素タイムライン
 * @param {number} startMs - 開始時間（ミリ秒）
 * @param {number} endMs - 終了時間（ミリ秒）
 * @returns {array} 指定範囲内の音素
 */
export function getPhonemesByTimeRange(timeline, startMs, endMs) {
  return timeline.filter(item => {
    // 時間範囲と重複している音素を抽出
    return item.start_ms < endMs && item.end_ms > startMs;
  });
}

/**
 * タイムラインの統計情報を取得
 * 
 * @param {array} timeline - 音素タイムライン
 * @returns {object} 統計情報
 */
export function getTimelineStats(timeline) {
  if (timeline.length === 0) {
    return {
      totalDuration: 0,
      phonemeCount: 0,
      uniquePhonemes: 0,
      averageDuration: 0,
    };
  }
  
  const totalDuration = timeline[timeline.length - 1].end_ms;
  const phonemeCount = timeline.length;
  const uniquePhonemes = new Set(timeline.map(p => p.phoneme)).size;
  const averageDuration = totalDuration / phonemeCount;
  
  return {
    totalDuration,
    phonemeCount,
    uniquePhonemes,
    averageDuration,
  };
}

/**
 * デバッグ用: タイムラインを文字列で表示
 * 
 * @param {array} timeline - 音素タイムライン
 * @returns {string} フォーマットされたタイムライン文字列
 */
export function debugTimelineString(timeline) {
  return timeline
    .map(item => `${item.phoneme}(${item.start_ms.toFixed(0)}-${item.end_ms.toFixed(0)}ms)`)
    .join(' → ');
}
