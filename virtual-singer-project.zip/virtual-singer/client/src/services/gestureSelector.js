/**
 * ジェスチャー選択サービス
 * テキスト分析結果に基づいて、適切なジェスチャー動画を選択
 */

import { analyzeText, recommendGestureCategory } from '../utils/textAnalyzer';

/**
 * テキストに基づいてジェスチャー動画を選択
 * 
 * @param {string} text - 入力テキスト
 * @param {object} manifest - 動画マニフェスト（video-manifest.json）
 * @returns {object} 選択されたジェスチャー情報
 * 
 * @example
 * const gesture = selectGesture('こんにちは！', manifest);
 * // { id: 'gesture_greeting_01', url: '...', duration_ms: 2000, category: 'greeting' }
 */
export function selectGesture(text, manifest) {
  // テキストを分析
  const analysis = analyzeText(text);
  
  // 推奨されるジェスチャーカテゴリを取得
  const recommendedCategory = recommendGestureCategory(analysis);
  
  // マニフェストから該当カテゴリのジェスチャーを取得
  const gestures = getGesturesByCategory(manifest, recommendedCategory);
  
  if (gestures.length === 0) {
    // フォールバック: idle カテゴリから選択
    const idleGestures = getGesturesByCategory(manifest, 'idle');
    if (idleGestures.length > 0) {
      return idleGestures[0];
    }
    // さらにフォールバック: 最初のジェスチャーを返す
    const allGestures = Object.entries(manifest.gesture || {})
      .filter(([key]) => !key.startsWith('_'))
      .map(([key, value]) => ({ id: key, ...value }));
    return allGestures[0] || null;
  }
  
  // 複数のジェスチャーがある場合、ランダムに選択
  return gestures[Math.floor(Math.random() * gestures.length)];
}

/**
 * マニフェストからカテゴリ別にジェスチャーを取得
 * 
 * @param {object} manifest - 動画マニフェスト
 * @param {string} category - ジェスチャーカテゴリ
 * @returns {array} 該当カテゴリのジェスチャー配列
 */
export function getGesturesByCategory(manifest, category) {
  if (!manifest || !manifest.gesture) {
    return [];
  }
  
  return Object.entries(manifest.gesture)
    .filter(([key, value]) => {
      // キーが '_' で始まる場合はスキップ（コメント等）
      if (key.startsWith('_')) return false;
      // カテゴリが一致するもののみ
      return value.category === category;
    })
    .map(([key, value]) => ({
      id: key,
      ...value,
    }));
}

/**
 * マニフェストから全てのジェスチャーカテゴリを取得
 * 
 * @param {object} manifest - 動画マニフェスト
 * @returns {array} ユニークなカテゴリ配列
 */
export function getAllGestureCategories(manifest) {
  if (!manifest || !manifest.gesture) {
    return [];
  }
  
  const categories = new Set();
  
  Object.entries(manifest.gesture).forEach(([key, value]) => {
    if (!key.startsWith('_') && value.category) {
      categories.add(value.category);
    }
  });
  
  return Array.from(categories);
}

/**
 * マニフェストから全てのジェスチャーを取得
 * 
 * @param {object} manifest - 動画マニフェスト
 * @returns {array} 全ジェスチャー配列
 */
export function getAllGestures(manifest) {
  if (!manifest || !manifest.gesture) {
    return [];
  }
  
  return Object.entries(manifest.gesture)
    .filter(([key]) => !key.startsWith('_'))
    .map(([key, value]) => ({
      id: key,
      ...value,
    }));
}

/**
 * 複数のテキストセグメントに基づいて、複数のジェスチャーを選択
 * （長いテキストを複数のセグメントに分割して、それぞれに異なるジェスチャーを割り当てる場合に使用）
 * 
 * @param {array} textSegments - テキストセグメント配列
 * @param {object} manifest - 動画マニフェスト
 * @returns {array} 選択されたジェスチャー配列
 */
export function selectGesturesForSegments(textSegments, manifest) {
  return textSegments.map(segment => selectGesture(segment, manifest));
}

/**
 * テキストを複数のセグメントに分割
 * 句読点（。、！？）で分割
 * 
 * @param {string} text - 入力テキスト
 * @returns {array} テキストセグメント配列
 */
export function splitTextIntoSegments(text) {
  // 句読点で分割し、句読点を含める
  const segments = text.split(/(?<=[。、！？])/);
  
  // 空のセグメントを除去
  return segments.filter(s => s.trim().length > 0);
}
