/**
 * 音声合成サービス
 * Web Speech API を使用した音声生成
 * （Google TTS API への切り替えは後続フェーズで実装）
 */

/**
 * Web Speech API を使用して音声を合成
 * ブラウザのネイティブ音声合成機能を利用
 * 
 * @param {string} text - 合成対象のテキスト
 * @param {object} options - オプション設定
 * @returns {Promise<Blob>} 音声 Blob
 * 
 * @example
 * const audioBlob = await synthesizeSpeech('こんにちは', {
 *   rate: 1.0,
 *   pitch: 1.0,
 *   volume: 1.0,
 * });
 */
export async function synthesizeSpeech(text, options = {}) {
  const {
    rate = 1.0,      // 話速（0.1 ～ 10）
    pitch = 1.0,     // 音高（0 ～ 2）
    volume = 1.0,    // 音量（0 ～ 1）
    lang = 'ja-JP',  // 言語
  } = options;
  
  return new Promise((resolve, reject) => {
    const synth = window.speechSynthesis;
    
    // 前回の発話をキャンセル
    synth.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = rate;
    utterance.pitch = pitch;
    utterance.volume = volume;
    utterance.lang = lang;
    
    // 音声出力を MediaRecorder でキャプチャ
    let audioContext;
    let mediaStream;
    let mediaRecorder;
    let audioChunks = [];
    
    utterance.onstart = () => {
      // AudioContext と MediaRecorder を初期化
      try {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const destination = audioContext.createMediaStreamDestination();
        mediaStream = destination.stream;
        
        mediaRecorder = new MediaRecorder(mediaStream);
        audioChunks = [];
        
        mediaRecorder.ondataavailable = (event) => {
          audioChunks.push(event.data);
        };
        
        mediaRecorder.onstop = () => {
          const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
          resolve(audioBlob);
        };
        
        mediaRecorder.start();
      } catch (error) {
        console.warn('AudioContext initialization failed:', error);
        // フォールバック: 無音の Blob を返す
        const emptyBlob = new Blob([], { type: 'audio/wav' });
        resolve(emptyBlob);
      }
    };
    
    utterance.onend = () => {
      if (mediaRecorder && mediaRecorder.state === 'recording') {
        mediaRecorder.stop();
      }
    };
    
    utterance.onerror = (event) => {
      console.error('Speech synthesis error:', event.error);
      reject(new Error(`Speech synthesis failed: ${event.error}`));
    };
    
    // 音声合成を開始
    synth.speak(utterance);
  });
}

/**
 * 音声 Blob から継続時間を取得
 * 
 * @param {Blob} audioBlob - 音声 Blob
 * @returns {Promise<number>} 継続時間（秒）
 */
export async function getAudioDuration(audioBlob) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(audioBlob);
    const audio = new Audio();
    
    audio.onloadedmetadata = () => {
      URL.revokeObjectURL(url);
      resolve(audio.duration);
    };
    
    audio.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load audio metadata'));
    };
    
    audio.src = url;
  });
}

/**
 * 音声 Blob を再生（テスト用）
 * 
 * @param {Blob} audioBlob - 音声 Blob
 */
export function playAudio(audioBlob) {
  const url = URL.createObjectURL(audioBlob);
  const audio = new Audio();
  audio.src = url;
  audio.play().catch(error => {
    console.error('Failed to play audio:', error);
  });
}

/**
 * 利用可能な音声を取得（Web Speech API）
 * 
 * @returns {Promise<array>} 利用可能な音声配列
 */
export async function getAvailableVoices() {
  const synth = window.speechSynthesis;
  
  return new Promise((resolve) => {
    const voices = synth.getVoices();
    
    if (voices.length > 0) {
      resolve(voices);
    } else {
      // 音声リストが読み込まれるまで待機
      synth.onvoiceschanged = () => {
        resolve(synth.getVoices());
      };
    }
  });
}

/**
 * 日本語の音声を取得
 * 
 * @returns {Promise<SpeechSynthesisVoice|null>} 日本語の音声、見つからない場合は null
 */
export async function getJapaneseVoice() {
  const voices = await getAvailableVoices();
  
  // 日本語の音声を検索
  return voices.find(voice => voice.lang.startsWith('ja')) || null;
}

/**
 * 音声合成が利用可能かチェック
 * 
 * @returns {boolean} 利用可能な場合は true
 */
export function isSpeechSynthesisAvailable() {
  return 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;
}

/**
 * Google TTS API を使用した音声合成（バックエンド経由）
 * 注意: このメソッドは後続フェーズで実装予定
 * 
 * @param {string} text - 合成対象のテキスト
 * @param {object} options - オプション設定
 * @returns {Promise<Blob>} 音声 Blob
 */
export async function synthesizeSpeechWithGoogleTTS(text, options = {}) {
  const {
    rate = 1.0,
    pitch = 1.0,
    volume = 1.0,
  } = options;
  
  try {
    const response = await fetch('/api/tts/synthesize', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text,
        rate,
        pitch,
        volume,
      }),
    });
    
    if (!response.ok) {
      throw new Error(`TTS API error: ${response.statusText}`);
    }
    
    return await response.blob();
  } catch (error) {
    console.error('Google TTS synthesis failed:', error);
    throw error;
  }
}
