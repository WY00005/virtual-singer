/**
 * 動画生成統合サービス
 * テキスト入力から完成動画まで、全プロセスを統合管理
 */

import { kanaToRomaji } from '../utils/kanaToRomaji';
import { analyzeText } from '../utils/textAnalyzer';
import { createPhonemeTimeline } from './phoneme';
import { selectGestures } from './gestureSelector';
import { synthesizeText } from './tts';
import { getVideoCompositor } from './videoCompositor';

class VideoGenerator {
  constructor(videoManifest) {
    this.videoManifest = videoManifest;
    this.compositor = getVideoCompositor();
  }

  /**
   * テキストから完成動画を生成
   * @param {string} text - 入力テキスト
   * @param {Object} options - 生成オプション
   * @param {Function} onProgress - 進捗コールバック
   * @returns {Promise<Blob>} 生成された動画
   */
  async generateVideo(text, options = {}, onProgress = null) {
    const {
      selectedGestures = [],
      voiceSpeed = 1.0,
      outputFormat = 'mp4',
    } = options;

    try {
      // ステップ1: テキスト分析
      this._reportProgress(onProgress, 5, 'テキストを分析しています...');
      const analysis = analyzeText(text);

      // ステップ2: 音声合成
      this._reportProgress(onProgress, 15, '音声を合成しています...');
      const audioBlob = await synthesizeText(text, { speed: voiceSpeed });
      const audioUrl = URL.createObjectURL(audioBlob);

      // ステップ3: タイムライン生成
      this._reportProgress(onProgress, 30, 'タイムラインを生成しています...');
      const romaji = kanaToRomaji(text);
      const timeline = createPhonemeTimeline(romaji, audioBlob, this.videoManifest);

      // ステップ4: ジェスチャー選択
      this._reportProgress(onProgress, 45, 'ジェスチャーを選択しています...');
      const gestures = selectedGestures.length > 0
        ? selectedGestures
        : selectGestures(analysis, this.videoManifest);

      // ステップ5: 動画クリップ生成
      this._reportProgress(onProgress, 60, '動画クリップを生成しています...');
      const videoClips = await this._generateVideoClips(timeline, gestures);

      // ステップ6: 動画連結
      this._reportProgress(onProgress, 75, '動画を連結しています...');
      let compositeVideo = videoClips[0];
      if (videoClips.length > 1) {
        compositeVideo = await this.compositor.concatenateVideos(videoClips, {
          outputFormat,
          onProgress: (progress) => {
            this._reportProgress(onProgress, 75 + (progress * 0.15), '動画を連結しています...');
          },
        });
      }

      // ステップ7: 音声合成
      this._reportProgress(onProgress, 90, '音声を合成しています...');
      const finalVideo = await this.compositor.composeVideoWithAudio(
        compositeVideo,
        audioBlob,
        {
          outputFormat,
          onProgress: (progress) => {
            this._reportProgress(onProgress, 90 + (progress * 0.09), '音声を合成しています...');
          },
        }
      );

      // ステップ8: 完成
      this._reportProgress(onProgress, 100, '完成しました！');

      // リソースをクリア
      URL.revokeObjectURL(audioUrl);

      return finalVideo;
    } catch (error) {
      console.error('[VideoGenerator] Failed to generate video:', error);
      throw error;
    }
  }

  /**
   * タイムラインから動画クリップを生成
   * @private
   */
  async _generateVideoClips(timeline, gestures) {
    const clips = [];

    for (const segment of timeline) {
      const { phoneme, startTime, duration, gestureId } = segment;

      // マニフェストから対応する動画を取得
      const mouthVideo = this.videoManifest.mouths?.find(m => m.phoneme === phoneme);
      const gestureVideo = this.videoManifest.gestures?.find(g => g.id === gestureId);

      if (mouthVideo && gestureVideo) {
        // 動画クリップを作成（実装は省略）
        // 実際には、FFmpeg または Canvas を使用して合成
        clips.push({
          mouth: mouthVideo.url,
          gesture: gestureVideo.url,
          startTime,
          duration,
        });
      }
    }

    return clips;
  }

  /**
   * 進捗を報告
   * @private
   */
  _reportProgress(onProgress, progress, status) {
    if (onProgress) {
      onProgress({
        progress: Math.min(progress, 100),
        status,
      });
    }
  }
}

export function createVideoGenerator(videoManifest) {
  return new VideoGenerator(videoManifest);
}

export default VideoGenerator;
