# Virtual Singer - Lip-sync Video Generation System

バーチャルシンガー リップシンク動画生成システムは、テキスト入力から自動的にリップシンクとジェスチャーを伴う動画を生成するWebアプリケーションです。

## 概要

このシステムは、以下の主要機能を備えています：

- **テキスト入力による音声合成**: Web Speech API またはGoogle TTS APIを使用した自然な音声生成
- **音素単位での口形動画選択**: ひらがなテキストをローマ字音素に変換し、対応する口形動画を自動選択
- **コンテキストに応じたジェスチャー動画選択**: テキスト分析により、感情や強調に応じたジェスチャーを自動選択
- **ブラウザ内での動画合成**: FFmpeg.wasmを使用して、ブラウザ内で動画を合成
- **完成動画のダウンロード**: MP4形式で完成動画をダウンロード可能

## 技術スタック

### フロントエンド
- **フレームワーク**: React 19
- **ビルドツール**: Vite
- **スタイリング**: Tailwind CSS 4
- **動画処理**: FFmpeg.wasm
- **音声合成**: Web Speech API / Google TTS API

### バックエンド
- **サーバー**: Node.js + Express 4
- **API**: tRPC 11
- **データベース**: MySQL / TiDB (Drizzle ORM)
- **認証**: Manus OAuth

### 外部サービス
- **動画ストレージ**: Cloudflare R2
- **音声合成**: Google Text-to-Speech API (オプション)

## プロジェクト構成

```
virtual-singer/
├── client/                    # React フロントエンド
│   ├── public/
│   │   ├── video-manifest.json
│   │   └── index.html
│   ├── src/
│   │   ├── components/        # UI コンポーネント
│   │   ├── services/          # ビジネスロジック
│   │   ├── utils/             # ユーティリティ関数
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   └── index.css
│   ├── package.json
│   └── vite.config.js
├── server/                    # Node.js バックエンド
│   ├── routes/
│   ├── services/
│   ├── server.js
│   └── package.json
├── shared/                    # 共通定義
│   └── phonemeMapping.js
├── drizzle/                   # データベーススキーマ
│   └── schema.ts
└── README.md
```

## セットアップ

### 必要な環境
- Node.js 18+
- npm または pnpm

### インストール

```bash
# リポジトリをクローン
git clone https://github.com/yourusername/virtual-singer.git
cd virtual-singer

# 依存関係をインストール
pnpm install

# 環境変数を設定
cp .env.example .env.local

# データベースをセットアップ
pnpm db:push

# 開発サーバーを起動
pnpm dev
```

## 使用方法

1. **テキスト入力**: アプリケーションのテキスト入力フォームに、日本語のテキストを入力
2. **音声合成**: 「生成」ボタンをクリック
3. **動画合成**: システムが自動的に音素タイムラインを生成し、動画を合成
4. **プレビュー**: 生成された動画をプレビュー
5. **ダウンロード**: 「ダウンロード」ボタンで動画をダウンロード

## 必要な素材

本システムを運用するには、以下の動画素材が必要です：

### 口形動画（約50個）
- 解像度: 512x512px
- フレームレート: 30fps
- 長さ: 200ms
- 背景: 透明またはクロマキー

### ジェスチャー動画（約15個）
- 解像度: 1080p または 720p
- フレームレート: 30fps
- 長さ: 2～3秒

### 動画マニフェスト
- JSON形式で、全ての動画素材のURL、継続時間、カテゴリを定義

詳細は `docs/video-requirements.md` を参照してください。

## 開発フェーズ

- [x] フェーズ1: プロジェクト初期設定
- [x] フェーズ2: データ処理ロジック実装
- [x] フェーズ3: 音声合成とタイムライン生成
- [x] フェーズ4: フロントエンドUI実装
- [x] フェーズ5: FFmpeg.wasm動画合成
- [ ] フェーズ6: 統合テストとデバッグ
- [ ] フェーズ7: 最終成果物提供

## デプロイ

### Manus プラットフォームでのデプロイ

1. Management UI の「Publish」ボタンをクリック
2. チェックポイントを作成してデプロイ

### Replit への同期

```bash
# Git コミット
git add -A
git commit -m "Update: [description]"

# Replit へプッシュ
git push origin main
```

## ライセンス

MIT License - See LICENSE file for details

## ユーザーガイド

詳細な使用方法は `userGuide.md` を参照してください。

## 参考資料

- [要件定義書](./docs/requirements.md)
- [API ドキュメント](./docs/api.md)
- [動画素材仕様](./docs/video-requirements.md)

## サポート

問題が発生した場合は、GitHubのIssueを作成してください。
