# Virtual Singer - Project TODO

## Replit Migration

- [x] Replit プロジェクト作成（SynthSinger）
- [x] GitHub リポジトリ初期化と連携
- [x] Replit への定期的なアップロード設定
- [x] 外部アクセス確認

## Core Features

- [x] テキスト入力フォーム UI (TextInput.tsx)
- [x] 動画マニフェスト読み込みロジック (video-manifest.json)
- [x] ひらがな→ローマ字変換 (kanaToRomaji.js)
- [x] 音素マッピング定義 (phonemeMapping.js)
- [x] テキスト感情分析 (textAnalyzer.js)
- [x] 音声合成サービス (tts.js - Web Speech API)
- [x] 音素タイムライン生成 (createPhonemeTimeline)
- [x] ジェスチャー選択ロジック (GestureSelector.tsx)
- [x] FFmpeg.wasm 動画合成 (videoCompositor.js)
- [x] プログレスバー UI (ProgressBar.tsx)
- [x] 動画プレビュー UI (VideoPreview.tsx)
- [x] ダウンロードボタン (DownloadButton.tsx)
- [x] メインアプリケーション UI (Home.tsx)

## Backend Services

- [ ] Express サーバー初期設定 (server.js)
- [ ] Google TTS API プロキシ (ttsService.js)
- [ ] 音素抽出 API (phonemeService.js)
- [ ] API ルート定義 (routes/api.js)

## Database Schema

- [ ] ユーザーテーブル (users)
- [ ] 生成動画履歴テーブル (video_generations)

## Integration & Testing

- [ ] Cloudflare R2 連携テスト
- [ ] FFmpeg.wasm 動画合成テスト
- [ ] 音素タイムラインと音声の同期テスト
- [ ] 全機能統合テスト

## Documentation

- [x] README.md 更新
- [x] userGuide.md 作成
