/**
 * 音素マッピング定義
 * ローマ字音素から動画素材ファイル名への対応関係を定義
 * 
 * 注意: このマッピングは、Cloudflare R2にアップロードされた
 * 動画素材のファイル名と一致している必要があります。
 * ユーザーが提供する video-manifest.json と同期を取ってください。
 */

export const PHONEME_MAPPING = {
  // 母音（5個）
  'a': { category: 'vowel', duration_ms: 200 },
  'i': { category: 'vowel', duration_ms: 200 },
  'u': { category: 'vowel', duration_ms: 200 },
  'e': { category: 'vowel', duration_ms: 200 },
  'o': { category: 'vowel', duration_ms: 200 },
  
  // か行（5個）
  'ka': { category: 'ka-row', duration_ms: 200 },
  'ki': { category: 'ka-row', duration_ms: 200 },
  'ku': { category: 'ka-row', duration_ms: 200 },
  'ke': { category: 'ka-row', duration_ms: 200 },
  'ko': { category: 'ka-row', duration_ms: 200 },
  
  // さ行（5個）
  'sa': { category: 'sa-row', duration_ms: 200 },
  'shi': { category: 'sa-row', duration_ms: 200 },
  'su': { category: 'sa-row', duration_ms: 200 },
  'se': { category: 'sa-row', duration_ms: 200 },
  'so': { category: 'sa-row', duration_ms: 200 },
  
  // た行（5個）
  'ta': { category: 'ta-row', duration_ms: 200 },
  'chi': { category: 'ta-row', duration_ms: 200 },
  'tsu': { category: 'ta-row', duration_ms: 200 },
  'te': { category: 'ta-row', duration_ms: 200 },
  'to': { category: 'ta-row', duration_ms: 200 },
  
  // な行（5個）
  'na': { category: 'na-row', duration_ms: 200 },
  'ni': { category: 'na-row', duration_ms: 200 },
  'nu': { category: 'na-row', duration_ms: 200 },
  'ne': { category: 'na-row', duration_ms: 200 },
  'no': { category: 'na-row', duration_ms: 200 },
  
  // は行（5個）
  'ha': { category: 'ha-row', duration_ms: 200 },
  'hi': { category: 'ha-row', duration_ms: 200 },
  'fu': { category: 'ha-row', duration_ms: 200 },
  'he': { category: 'ha-row', duration_ms: 200 },
  'ho': { category: 'ha-row', duration_ms: 200 },
  
  // ま行（5個）
  'ma': { category: 'ma-row', duration_ms: 200 },
  'mi': { category: 'ma-row', duration_ms: 200 },
  'mu': { category: 'ma-row', duration_ms: 200 },
  'me': { category: 'ma-row', duration_ms: 200 },
  'mo': { category: 'ma-row', duration_ms: 200 },
  
  // や行（3個）
  'ya': { category: 'ya-row', duration_ms: 200 },
  'yu': { category: 'ya-row', duration_ms: 200 },
  'yo': { category: 'ya-row', duration_ms: 200 },
  
  // ら行（5個）
  'ra': { category: 'ra-row', duration_ms: 200 },
  'ri': { category: 'ra-row', duration_ms: 200 },
  'ru': { category: 'ra-row', duration_ms: 200 },
  're': { category: 'ra-row', duration_ms: 200 },
  'ro': { category: 'ra-row', duration_ms: 200 },
  
  // わ行（3個）
  'wa': { category: 'wa-row', duration_ms: 200 },
  'wo': { category: 'wa-row', duration_ms: 200 },
  'n': { category: 'wa-row', duration_ms: 200 },
  
  // 拗音（きゃ行）
  'kya': { category: 'kya-row', duration_ms: 200 },
  'kyu': { category: 'kya-row', duration_ms: 200 },
  'kyo': { category: 'kya-row', duration_ms: 200 },
  
  // 拗音（しゃ行）
  'sha': { category: 'sha-row', duration_ms: 200 },
  'shu': { category: 'sha-row', duration_ms: 200 },
  'sho': { category: 'sha-row', duration_ms: 200 },
  
  // 拗音（ちゃ行）
  'cha': { category: 'cha-row', duration_ms: 200 },
  'chu': { category: 'cha-row', duration_ms: 200 },
  'cho': { category: 'cha-row', duration_ms: 200 },
  
  // 拗音（にゃ行）
  'nya': { category: 'nya-row', duration_ms: 200 },
  'nyu': { category: 'nya-row', duration_ms: 200 },
  'nyo': { category: 'nya-row', duration_ms: 200 },
  
  // 拗音（ひゃ行）
  'hya': { category: 'hya-row', duration_ms: 200 },
  'hyu': { category: 'hya-row', duration_ms: 200 },
  'hyo': { category: 'hya-row', duration_ms: 200 },
  
  // 拗音（みゃ行）
  'mya': { category: 'mya-row', duration_ms: 200 },
  'myu': { category: 'mya-row', duration_ms: 200 },
  'myo': { category: 'mya-row', duration_ms: 200 },
  
  // 拗音（りゃ行）
  'rya': { category: 'rya-row', duration_ms: 200 },
  'ryu': { category: 'rya-row', duration_ms: 200 },
  'ryo': { category: 'rya-row', duration_ms: 200 },
  
  // 拗音（ぎゃ行）
  'gya': { category: 'gya-row', duration_ms: 200 },
  'gyu': { category: 'gya-row', duration_ms: 200 },
  'gyo': { category: 'gya-row', duration_ms: 200 },
  
  // 拗音（じゃ行）
  'ja': { category: 'ja-row', duration_ms: 200 },
  'ju': { category: 'ja-row', duration_ms: 200 },
  'jo': { category: 'ja-row', duration_ms: 200 },
  
  // 拗音（びゃ行）
  'bya': { category: 'bya-row', duration_ms: 200 },
  'byu': { category: 'bya-row', duration_ms: 200 },
  'byo': { category: 'bya-row', duration_ms: 200 },
  
  // 拗音（ぴゃ行）
  'pya': { category: 'pya-row', duration_ms: 200 },
  'pyu': { category: 'pya-row', duration_ms: 200 },
  'pyo': { category: 'pya-row', duration_ms: 200 },
  
  // 濁音（が行）
  'ga': { category: 'ga-row', duration_ms: 200 },
  'gi': { category: 'ga-row', duration_ms: 200 },
  'gu': { category: 'ga-row', duration_ms: 200 },
  'ge': { category: 'ga-row', duration_ms: 200 },
  'go': { category: 'ga-row', duration_ms: 200 },
  
  // 濁音（ざ行）
  'za': { category: 'za-row', duration_ms: 200 },
  'ji': { category: 'za-row', duration_ms: 200 },
  'zu': { category: 'za-row', duration_ms: 200 },
  'ze': { category: 'za-row', duration_ms: 200 },
  'zo': { category: 'za-row', duration_ms: 200 },
  
  // 濁音（だ行）
  'da': { category: 'da-row', duration_ms: 200 },
  'de': { category: 'da-row', duration_ms: 200 },
  'do': { category: 'da-row', duration_ms: 200 },
  
  // 濁音（ば行）
  'ba': { category: 'ba-row', duration_ms: 200 },
  'bi': { category: 'ba-row', duration_ms: 200 },
  'bu': { category: 'ba-row', duration_ms: 200 },
  'be': { category: 'ba-row', duration_ms: 200 },
  'bo': { category: 'ba-row', duration_ms: 200 },
  
  // 半濁音（ぱ行）
  'pa': { category: 'pa-row', duration_ms: 200 },
  'pi': { category: 'pa-row', duration_ms: 200 },
  'pu': { category: 'pa-row', duration_ms: 200 },
  'pe': { category: 'pa-row', duration_ms: 200 },
  'po': { category: 'pa-row', duration_ms: 200 },
  
  // 特殊
  'silence': { category: 'special', duration_ms: 100 },
};

/**
 * 音素が有効かどうかを確認
 * @param {string} phoneme - 音素
 * @returns {boolean} 有効な場合は true
 */
export function isValidPhoneme(phoneme) {
  return phoneme in PHONEME_MAPPING;
}

/**
 * 音素の継続時間を取得
 * @param {string} phoneme - 音素
 * @returns {number} 継続時間（ミリ秒）
 */
export function getPhonememeDuration(phoneme) {
  const mapping = PHONEME_MAPPING[phoneme];
  return mapping ? mapping.duration_ms : 200;
}

/**
 * 音素のカテゴリを取得
 * @param {string} phoneme - 音素
 * @returns {string} カテゴリ
 */
export function getPhonemeCategory(phoneme) {
  const mapping = PHONEME_MAPPING[phoneme];
  return mapping ? mapping.category : 'unknown';
}

/**
 * 全ての有効な音素リストを取得
 * @returns {string[]} 音素リスト
 */
export function getAllPhonemes() {
  return Object.keys(PHONEME_MAPPING);
}
